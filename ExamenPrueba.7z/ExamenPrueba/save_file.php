<?php
    //include("crear_alumno.php");

    class File //extends Alumno
    {
        public function __construct() 
        {                 
        }

        function CargarProveedor($path, $miAlumno)
        {
            try 
            {
                header('Content-Type: text/txt');
                header('Content-Disposition: attachment; filename="sample.txt"');
                
                $data = array(
                        $miAlumno
                );
            
                $fp = fopen('proveedores.txt', 'a+');
                if($data != null)
                {
                    foreach ( $data as $line ) 
                    {
                        $val = explode("|", $line);
                        fputs($fp, $line."\n\r");
                    }
                    fclose($fp);
                }
                else
                {
                    fclose($fp);
                    throw new Exception("no se pudo guardar");  
                }
            
            }
            catch(Exception $ex)
            {
                 
            }
            
        }

        function ObtenerUltimoId($fileName)
        {
            $file = fopen($fileName, "r") or exit("Unable to open file!");
            while(!feof($file))
            {
                //echo fgets($file). "<br />";
                $texto = fgets($file);
                $array = explode(",", $texto); 
                echo  split("}",$array[3]) ;         
            }
         
            fclose($file);

        }

        function cargarFoto()
        {
                    # definimos la carpeta destino
            $carpetaDestino="imagenes/";
        
            # si hay algun archivo que subir
            if(isset($_FILES["archivo"]) && $_FILES["archivo"]["name"][0])
            {
        
                # recorremos todos los arhivos que se han subido
                for($i=0;$i<count($_FILES["archivo"]["name"]);$i++)
                {
        
                    # si es un formato de imagen
                    if($_FILES["archivo"]["type"][$i]=="image/jpeg" || $_FILES["archivo"]["type"][$i]=="image/pjpeg" || $_FILES["archivo"]["type"][$i]=="image/gif" || $_FILES["archivo"]["type"][$i]=="image/png")
                    {
        
                        # si exsite la carpeta o se ha creado
                        if(file_exists($carpetaDestino) || @mkdir($carpetaDestino))
                        {
                            $origen=$_FILES["archivo"]["tmp_name"][$i];
                            $destino=$carpetaDestino.$_FILES["archivo"]["name"][$i];
        
                            # movemos el archivo
                            if(@move_uploaded_file($origen, $destino))
                            {
                                echo "<br>".$_FILES["archivo"]["name"][$i]." movido correctamente";
                            }else{
                                echo "<br>No se ha podido mover el archivo: ".$_FILES["archivo"]["name"][$i];
                            }
                        }else{
                            echo "<br>No se ha podido crear la carpeta: ".$carpetaDestino;
                        }
                    }else{
                        echo "<br>".$_FILES["archivo"]["name"][$i]." - NO es imagen jpg, png o gif";
                    }
                }
            }else{
                echo "<br>No se ha subido ninguna imagen";
            }

        }

    }


?>