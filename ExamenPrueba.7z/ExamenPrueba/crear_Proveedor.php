<?php
    include_once("proveedor.php");
    include("save_file.php");
    //include("AccesoDatos.php");
    
    if (//isset($_POST['Id']) &&
        isset($_POST['Nombre']) &&
        isset($_POST['Email']) &&
        isset($_POST['Foto'])) 
    {
       // $id=$_POST['Id'];
        $nombre=$_POST['Nombre'];
        $email=$_POST['Email'];
        $foto=$_POST['Foto'];
        //empty($id)||
        if(empty($nombre)||empty($email)||empty($foto))
        {
            echo "Some variables weren't setted correctly\n";
        }
        else
        {
            echo "the variables were setted successfully: \n";
            //$miAlumno = new Alumno($nombre, $edad, $dni, $legajo);
            $proveedor = new Proveedor();
            
             $proveedor->setId(); 
             $proveedor->setNombre($nombre);
             $proveedor-> setEmail($email);
             $proveedor->setFoto($foto);
                   
            //$proveedor->Insertar();
             
            $miArchivo = new File();


        }
    }

?>