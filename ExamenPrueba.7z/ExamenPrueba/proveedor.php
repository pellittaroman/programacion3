<?php
    include("persona.php");
    //include("AccesoDatos.php");

    class Proveedor extends Persona implements JsonSerializable
    {
        protected $id = 0;
        protected $email;
        protected $foto;

        public function getId() 
        {
            return $this->id;
        }

        public function getArray() 
        {
            return $this->arrayId;
        }
        
        
        public function setId() 
        {
            $this->id = $this->id + 1;
        }
        public function getEmail() 
        {
            return $this->email;
        }

        public function setEmail($email) 
        {
            $this->email = $email;
        }
        public function getFoto() 
        {
            return $this->foto;
        }

        public function setFoto($foto) 
        {
            $this->foto = $foto;
        }
    
        public function jsonSerialize()
        {
            return 
            [
                'nombre'   => $this->getNombre(),
                'email'   => $this->getEmail(),
                'foto' => $this->getFoto(),
                'id' => $this->getId()
            ];
        }

        function retornarJSON()
        {
            return json_encode($this);
        }
        
        public function Insertar()
        {
                   $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
                   $consulta =$objetoAccesoDato->RetornarConsulta("INSERT into alumno (Nombre,Edad,Documento,Legajo)values(:nombre,:edad,:dni,:legajo)");
                   $consulta->bindValue(':nombre',$this->nombre, PDO::PARAM_STR);
                   $consulta->bindValue(':edad', $this->edad, PDO::PARAM_INT);
                   $consulta->bindValue(':dni',$this->dni, PDO::PARAM_STR);
                   $consulta->bindValue(':legajo', $this->legajo, PDO::PARAM_STR);
                   $consulta->execute();		
                   return $objetoAccesoDato->RetornarUltimoIdInsertado();
        }
    }
?>