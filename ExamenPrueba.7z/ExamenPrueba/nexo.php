
<?php
    include("crear_Proveedor.php");

     $proveedor->retornarJSON();
   //  echo $proveedor->retornarJSON();
    // echo "<br><br>";
    try
    {
        $miArchivo->CargarProveedor("asd", $proveedor->retornarJSON());
        $miArchivo->ObtenerUltimoId("proveedores.txt");
    }
    catch(Exception $ex)
    {
         echo $ex->getMessage();
    }
//nexo recibe los case. case get, case post
y luego en cada case hay un crear, editar o modificar
?>
