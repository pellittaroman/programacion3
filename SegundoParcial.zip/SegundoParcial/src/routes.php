<?php

use Slim\App;
use Slim\Http\Request;
use Slim\Http\Response;
require_once "../src/usuarioApi.php";
require_once "../src/materiaApi.php";
require_once "../src/MWparaAutentificar.php";
return function (App $app) {
    $container = $app->getContainer();
    $app->group('/usuario', function(){
        $this->post('[/]', \usuarioApi::class . ':CargarUno');
        $this->post('/{legajo}', \usuarioApi::class . ':ModificarUno')->add(\MWparaAutentificar::class . ':VerificarLogeo');
    });
    $app->post('/login', \usuarioApi::class . ':login');
    $app->post('/materia', \materiaApi::class . ':CargarUno')->add(\MWparaAutentificar::class . ':VerificarAdmin');
    $app->post('/inscripcion/{idMateria}', \usuarioApi::class . ':inscripcion')->add(\MWparaAutentificar::class . ':VerificarAlumno');
    $app->group('/materia', function(){
        $this->get('[/]', \usuarioApi::class . ':TraerUno')->add(\MWparaAutentificar::class . ':VerificarLogeo');
        $this->get('/{id}', \usuarioApi::class . ':TraerTodos')->add(\MWparaAutentificar::class . ':VerificarAdminPro');
    });
};
