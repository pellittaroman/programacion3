<?php  
namespace App\Models;
 
class materia extends \Illuminate\Database\Eloquent\Model {  
    public $timestamps = false;
}