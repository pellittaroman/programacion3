<?php
require_once "../src/AutentificadorJWT.php";
class MWparaAutentificar
{
 /**
   * @api {any} /MWparaAutenticar/  Verificar Usuario
   * @apiVersion 0.1.0
   * @apiName VerificarUsuario
   * @apiGroup MIDDLEWARE
   * @apiDescription  Por medio de este MiddleWare verifico las credeciales antes de ingresar al correspondiente metodo 
   *
   * @apiParam {ServerRequestInterface} request  El objeto REQUEST.
 * @apiParam {ResponseInterface} response El objeto RESPONSE.
 * @apiParam {Callable} next  The next middleware callable.
   *
   * @apiExample Como usarlo:
   *    ->add(\MWparaAutenticar::class . ':VerificarUsuario')
   */
	public function VerificarAdmin($request, $response, $next) {
         
		$objDelaRespuesta= new stdclass();
		$objDelaRespuesta->respuesta="";
	   
		if($request->isPost())
		{
			$arrayConToken = $request->getHeader('token');
			$token = $arrayConToken[0];
			$objDelaRespuesta->esValido=true;
			
			try 
			{
				AutentificadorJWT::verificarToken($token);
				$objDelaRespuesta->esValido=true;      
			}
			catch (Exception $e) {     
				$objDelaRespuesta->excepcion=$e->getMessage();
				$objDelaRespuesta->esValido=false;     
			}
			if($objDelaRespuesta->esValido)
			{						
				$payload=AutentificadorJWT::ObtenerData($token);
				
				if($payload->tipo=="admin")
				{
					$response = $next($request, $response);
					return $response;  
				}		           	
				else
				{	
					$objDelaRespuesta->respuesta="No tiene permiso para la operacion";
					$nueva=$response->withJson($objDelaRespuesta);
					return $nueva;
				}          
			}    
		}
		
		 
	}
	public function VerificarLogeo($request, $response, $next)
	{
		$objDelaRespuesta= new stdclass();
		$objDelaRespuesta->respuesta="";
	   
		if($request->isPost()||$request->isGet())
		{
			$arrayConToken = $request->getHeader('token');
			$token = $arrayConToken[0];
			$objDelaRespuesta->esValido=true;
			try 
			{
				AutentificadorJWT::verificarToken($token);
				$objDelaRespuesta->esValido=true;      
			}
			catch (Exception $e) {      
				$objDelaRespuesta->excepcion=$e->getMessage();
				$objDelaRespuesta->esValido=false;     
			}
			if($objDelaRespuesta->esValido)
			{	
				$response = $next($request, $response);   
			}
			else
			{
				$objDelaRespuesta->respuesta="Solo usuarios registrados";
				$nueva=$response->withJson($objDelaRespuesta, 401);  
				return $nueva;
			}
		}
	
		return $response;
	}
	public function VerificarAlumno($request, $response, $next) {
         
		$objDelaRespuesta= new stdclass();
		$objDelaRespuesta->respuesta="";
	   
		if($request->isPost())
		{
			$arrayConToken = $request->getHeader('token');
			$token = $arrayConToken[0];
			$objDelaRespuesta->esValido=true;
			
			try 
			{
				AutentificadorJWT::verificarToken($token);
				$objDelaRespuesta->esValido=true;      
			}
			catch (Exception $e) {     
				$objDelaRespuesta->excepcion=$e->getMessage();
				$objDelaRespuesta->esValido=false;     
			}
			if($objDelaRespuesta->esValido)
			{						
				$payload=AutentificadorJWT::ObtenerData($token);
				
				if($payload->tipo=="alumno")
				{
					$response = $next($request, $response);
					return $response;  
				}		           	
				else
				{	
					$objDelaRespuesta->respuesta="Operacion solo para alumnos";
					$nueva=$response->withJson($objDelaRespuesta);
					return $nueva;
				}          
			}    
		}
		
		 
	}

	public function VerificarAdminPro($request, $response, $next) {
         
		$objDelaRespuesta= new stdclass();
		$objDelaRespuesta->respuesta="";
	   
		if($request->isGet())
		{
			$arrayConToken = $request->getHeader('token');
			$token = $arrayConToken[0];
			$objDelaRespuesta->esValido=true;
			
			try 
			{
				AutentificadorJWT::verificarToken($token);
				$objDelaRespuesta->esValido=true;      
			}
			catch (Exception $e) {     
				$objDelaRespuesta->excepcion=$e->getMessage();
				$objDelaRespuesta->esValido=false;     
			}
			if($objDelaRespuesta->esValido)
			{						
				$payload=AutentificadorJWT::ObtenerData($token);
				
				if($payload->tipo=="admin"|| $payload->tipo=="profesor")
				{
					$response = $next($request, $response);
					return $response;  
				}		           	
				else
				{	
					$objDelaRespuesta->respuesta="No tiene permiso para la operacion";
					$nueva=$response->withJson($objDelaRespuesta);
					return $nueva;
				}          
			}    
		}
		
		 
	}
}