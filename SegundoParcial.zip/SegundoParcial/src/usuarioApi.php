<?php
require_once "../src/app/models/usuario.php";
require_once "../src/IApiUsable.php";
require_once "../src/AutentificadorJWT.php";
require_once "../src/agregarFoto.php";
require_once "../src/app/models/materia.php";
use App\Models;
use App\Models\usuario;
use  App\Models\materia;
class usuarioApi implements IApiUsable
{
    
    public function TraerUno($request, $response, $args)
    {
        $objDelaRespuesta= new stdclass();
        $arrayConToken = $request->getHeader('token');
        $token = $arrayConToken[0];
        $payload=AutentificadorJWT::ObtenerData($token);
        $materia=new materia();
        if($payload->tipo=="admin")
        {
            $materia=materia::all();
            $objDelaRespuesta->respuesta=$materia;
        }
        else    
        {    
            
            $j=0;
            $miUser=new usuario();
            $miUser=$miUser->where("legajo",$payload->legajo)->first();
            $explode=explode(",",$miUser->materias);
            for($i=0;$i<count($explode);$i++)
            {
                $materia=$materia->where("id",$explode[$i])->first();
                $objDelaRespuesta->respuesta[$j]=$materia;
                $j++;
            }
        }
        
        return $response->withJson($objDelaRespuesta, 200);
    }
    public function TraerTodos($request, $response, $args)
    {
        $objDelaRespuesta= new stdclass();
        $id=$args['id'];
        $arrayConToken = $request->getHeader('token');
        $token = $arrayConToken[0];
        $payload=AutentificadorJWT::ObtenerData($token);
        $todos = usuario::all();
        $materia=new materia();
        $materia=$materia->where('id',$id)->first();
        if($todos!=null&&$materia!=null)
        {

            if($payload->tipo=="admin"||$payload->legajo==$materia->aCargo)
            {
                $x=0;
                for ($i=0; $i <count($todos) ; $i++) 
                { 
                    
                    if($todos[$i]->tipo=="alumno")
                    {
                        $explode=explode(",",$todos[$i]->materias);
                        for($j=0;$j<count($explode);$j++)
                        {
                            if($explode[$j]==$materia->id)
                            {
                                
                                $miUser=new usuario();
                                $miUser=$miUser->where('legajo',$todos[$i]->legajo)->first();
                                $objDelaRespuesta->respuesta[$x]=$miUser;
                                $x++;
                            }
                        }
                    }
                }
                
                return $response->withJson($objDelaRespuesta, 200);
            }
            else
            {
                echo "Usted no esta a cargo de la materia";
            }
            
        }
        else
        {
            $objDelaRespuesta->respuesta="Error al leer la base de datos";
        }
        
    }
    public function CargarUno($request, $response, $args)
    {
        $objDelaRespuesta= new stdclass();
        
        $ArrayDeParametros = $request->getParsedBody();
        $nombre= $ArrayDeParametros['nombre'];
        $password= $ArrayDeParametros['clave'];
        if(strcasecmp($ArrayDeParametros['tipo'],"profesor")==0||strcasecmp($ArrayDeParametros['tipo'],"alumno")==0||strcasecmp($ArrayDeParametros['tipo'],"admin")==0)
        {
            $tipo=$ArrayDeParametros['tipo'];
        }
        else {
            echo "Error de tipo";
        }
        $todos = usuario::all();
        if(count($todos)==0)
        {
            $legajo=100;
        }
        else
        {
            for($i=0;$i<count($todos);$i++)
            {
                $index=$todos[$i]->legajo;
            }
            
            $legajo=$index+1;
        }
       
        
        $usuarioLogin = new usuario();
        
            $miUser = new usuario();
            $miUser->nombre=$nombre;
            $miUser->clave=$password;
            $miUser->legajo=$legajo;
            $miUser->tipo=$tipo;
            $miUser->save();
        
            $objDelaRespuesta->respuesta="Se cargo correctamente";  
                
        return $response->withJson($objDelaRespuesta, 200);
    }
    public function BorrarUno($request, $response, $args)
    {
    }
    public function ModificarUno($request, $response, $args)
    {
        
        $id=$args['legajo'];
        $miUser = new usuario();
        $miUser = $miUser->where('legajo', $id)->first(); 
        $arrayConToken = $request->getHeader('token');
        $token = $arrayConToken[0];
        $payload=AutentificadorJWT::ObtenerData($token);
        if($id==$payload->legajo)
        {
            if(isset($_POST['email']))
            {
                $email=$_POST['email'];
            }
            else
            {
                $email="";
            }
            if(isset($_FILES['foto']))
            {   
                $foto=cargar($_FILES,$id);
            }
            else {
                $foto="";
            }
            if(isset($_POST['materias']))
            {
                $explode = explode(",", $_POST['materias']);
                $materia = new materia();
            }
            else
            {
                $materias="";
            }
        switch($payload->tipo)
        {
            case 'alumno':
            $miUser->email=$email;
            $miUser->foto=$foto;
            try
            {
                $miUser->save();
                return $response->withJson("Se cargo correctamente", 200);
            }
            catch(Exception $e)
            {
                return $response->withJson($e->getMessage(), 401);
            }
            break;
            case 'profesor':
            $objDelaRespuesta= new stdclass();
            $miUser->email=$email;
            if($explode)
            {
                $control=0;
                for($i=0;$i<count($explode);$i++)
                {
                    $materia= $materia->where('id', $explode[$i])->first();
                    if($materia!="")
                    {
                        if($materia->aCargo=="")
                        {
                            $materia->aCargo=$id;
                            if($control==0)
                            {
                                $materias=$explode[$i];
                                $control++;
                            }
                            else
                            {
                                $materias.=", ";
                                $materias.=$explode[$i];
                            }
                        }
                        else
                        {
                            if($materia->aCargo==$miUser->legajo)
                            {
                                $objDelaRespuesta->materia[$materia->id]="Usted es el profesor a cargo de la materia";
                            
                                if($control==0)
                                {
                                    $materias=$explode[$i];
                                    $control=1;
                                }
                                else
                                {
                                    $materias.=", ";
                                    $materias.=$explode[$i];
                                }
                            }
                            else
                            {
                                $objDelaRespuesta->materia[$materia->id] = "Ya hay un profesor a cargo de esa materia";
                                $materia->aCargo=$id;
                                if($control==0)
                                {
                                    $materias=$explode[$i];
                                    $control=1;
                                }
                                else
                                {
                                    $materias.=", ";
                                    $materias.=$explode[$i];
                                }
                            }
                        }
                    $materia->save();                        
                    }
                    else
                    {
                        $objDelaRespuesta->materia[$explode[$i]] ="No se encontro materia con el ID ". $explode[$i];
                    }
                }
                $miUser->materias=$materias;
            }
            try
            {
                $miUser->save();
                $objDelaRespuesta->respuesta="Se realizo modificacion";
                return $response->withJson($objDelaRespuesta, 200);
            }
            catch(Exception $e)
            {
                return $response->withJson($e->getMessage(), 401);
            }
            break;
            case 'admin':
            $objDelaRespuesta= new stdclass();
            $miUser->email=$email;
            $miUser->foto=$foto;
            
            if($explode)
            {
                $control=0;
                for($i=0;$i<count($explode);$i++)
                {
                    $materia= $materia->where('id', $explode[$i])->first();
                    if($materia!="")
                    {
                        if($materia->aCargo=="")
                        {
                            $materia->aCargo=$id;
                            if($control==0)
                            {
                                $materias=$explode[$i];
                                $control++;
                            }
                            else
                            {
                                $materias.=", ";
                                $materias.=$explode[$i];
                            }
                        }
                        else
                        {
                            if($materia->aCargo==$miUser->legajo)
                            {
                                $objDelaRespuesta->materia[$materia->id]="Usted es el profesor a cargo de la materia";
                            
                                if($control==0)
                                {
                                    $materias=$explode[$i];
                                    $control=1;
                                }
                                else
                                {
                                    $materias.=", ";
                                    $materias.=$explode[$i];
                                }
                            }
                            else
                            {
                                $objDelaRespuesta->materia[$materia->id] = "Ya hay un profesor a cargo de esa materia";
                                $materia->aCargo=$id;
                                if($control==0)
                                {
                                    $materias=$explode[$i];
                                    $control=1;
                                }
                                else
                                {
                                    $materias.=", ";
                                    $materias.=$explode[$i];
                                }
                            }
                        }
                    $materia->save();                        
                    }
                    else
                    {
                        $objDelaRespuesta->materia[$explode[$i]] ="No se encontro materia con el ID ". $explode[$i];
                    }
                }
                $miUser->materias=$materias;
            }
            try
            {
                $miUser->save();
                $objDelaRespuesta->respuesta="Se realizo modificacion";
                return $response->withJson($objDelaRespuesta, 200);
            }
            catch(Exception $e)
            {
                return $response->withJson($e->getMessage(), 401);
            }
            break;
        }
        }
        else
        {
            echo "Solo puede modificar sus propios datos";
        }
        

    }
    public function Login($request, $response, $args)
    {
        
        
        $ArrayDeParametros = $request->getParsedBody();
        $nombre= $ArrayDeParametros['nombre'];
        $legajo= $ArrayDeParametros['legajo'];
        $usuarioLogin = new usuario();
        $usuarioLogin = $usuarioLogin->where('nombre', $nombre)->first();
        if($usuarioLogin)
        {
            if($usuarioLogin->nombre == $nombre && $usuarioLogin->legajo == $legajo)
            {
                $datos = array(
                    'nombre'=>$nombre,
                    'legajo'=>$legajo,
                    'clave'=>$usuarioLogin->clave,
                    'tipo'=>$usuarioLogin->tipo
                );
                return AutentificadorJWT::CrearToken($datos);
            }
            else
            {
                return $response->withJson("Nombre o legajo incorrectas");
            }
        }
        else
        {
            return $response->withJson("Nombre invalido", 200);
        }   
    }
    public function inscripcion($request, $response, $args)
    {   
        $id=$args['idMateria'];
        $materia=new materia();
        $materia= $materia->where('id', $id)->first();
        if($materia!=null)
        {
            if($materia->cupos>0)
            {
                $cupo=$materia->cupos -1;
                $arrayConToken = $request->getHeader('token');
                $token = $arrayConToken[0];
                $payload=AutentificadorJWT::ObtenerData($token);
                $miUser = new usuario();
                $miUser = $miUser->where('legajo', $payload->legajo)->first();
                if($miUser->materias=="")
                {
                    $miUser->materias=$id;
                    $miUser->save();
                    $materia->cupos=$cupo;
                    if($materia->inscriptos)
                    {
                        $materia->inscriptos.=", ".$miUser->legajo; 
                    }
                    else
                    {
                        $materia->inscriptos=$miUser->legajo;
                    }
                    
                    $materia->save();
                    return $response->withJson("Tu inscripcion ha sido prosesada");
                } 
                else
                {
                    $explode = explode(",", $miUser->materias);
                    $flag=0;
                    
                   for($i=0;$i<count($explode);$i++)
                   {
                        if($id == $explode[$i])
                        {
                            $flag=1;
                            break;
                        }
                    
                        else
                        {
                            if($i==0)
                            {
                                $actual=$explode[$i];     
                            }
                            else
                            {
                                $actual.=", ";
                                $actual.=$explode[$i];
                            }
                           
                        }
                        
                   }
                   if($flag==1)
                   {
                        return $response->withJson("Ya estas anotado en la materia");
                   }
                   else
                   {
                       
                       $actual.=", ";
                       $actual.=$id;
                       $miUser->materias=$actual;
                       $materia->cupos=$cupo;
                       $materia->inscriptos=$miUser->legajo;
                        try {
                           
                            $materia->save();
                            $miUser->save();
                            return $response->withJson("Tu inscripcion ha sido prosesada");
                        } catch (Exception $th) {
                            throw $th;
                        }
                   }
                }
            }
            else
            {
                echo "No hay lugares disponibles en esta materia";
            }
        }
        else
        {
            echo   "Id materia incorrecto";
        }
       
    }
}
?>