<?php
require_once "../src/app/models/materia.php";
require_once "../src/IApiUsable.php";
require_once "../src/AutentificadorJWT.php";
use App\Models;
use App\Models\materia;
class materiaApi implements IApiUsable
{
    
    public function TraerUno($request, $response, $args)
    {
        $objDelaRespuesta= new stdclass();
        $nombre=$args['id'];
        $user = materia::find($nombre);
        $objDelaRespuesta->respuesta=$user;
        return $response->withJson($objDelaRespuesta, 200);
    }
    public function TraerTodos($request, $response, $args)
    {
        $objDelaRespuesta= new stdclass();
        $todos = materia::all();
        $objDelaRespuesta->respuesta=$todos;
        return $response->withJson($objDelaRespuesta, 200);
    }
    public function CargarUno($request, $response, $args)
    {
        $objDelaRespuesta= new stdclass();
        
        $ArrayDeParametros = $request->getParsedBody();
        $nombre= $ArrayDeParametros['nombre'];
        $cuatrimestre= $ArrayDeParametros['cuatrimestre'];
        $cupo= $ArrayDeParametros['cupos'];
        $miUser = new materia();
        $miUser->nombre=$nombre;
        $miUser->cuatrimestre=$cuatrimestre;
        $miUser->cupos=$cupo;
        $miUser->save();
        
            $objDelaRespuesta->respuesta="Se cargo correctamente";  
                
        return $response->withJson($objDelaRespuesta, 200);
    }
    public function BorrarUno($request, $response, $args)
    {
    }
    public function ModificarUno($request, $response, $args)
    {
    }

}
?>